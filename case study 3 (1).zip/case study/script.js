// Add active class to current navigation item
document.addEventListener("DOMContentLoaded", () => {
  // Get current page URL
  const currentPage = window.location.pathname.split("/").pop()

  // Set active class based on current page
  const navLinks = document.querySelectorAll(".nav-links a")

  navLinks.forEach((link) => {
    // Get the href attribute
    const href = link.getAttribute("href")

    // Check if this link corresponds to the current page
    if (
      href === currentPage ||
      (currentPage === "" && href === "index.html") ||
      (currentPage === undefined && href === "index.html")
    ) {
      link.classList.add("active")
    } else {
      link.classList.remove("active")
    }

    // Add click event listener for navigation
    link.addEventListener("click", function () {
      navLinks.forEach((item) => item.classList.remove("active"))
      this.classList.add("active")
    })
  })

  // Form submission handling
  const contactForm = document.querySelector(".contact-form form")
  if (contactForm) {
    contactForm.addEventListener("submit", function (e) {
      e.preventDefault()
      alert("Thank you for your message! I will get back to you soon.")
      this.reset()
    })
  }
})

